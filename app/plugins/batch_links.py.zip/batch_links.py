import os
import re
import random
import asyncio
import logging
from typing import Optional, List

from telethon import events
from app.plugins.progress_live import DebouncedProgress
from app.utils.link_parser import extract_links
from app.services.joiner import probe_channel_id, ensure_join
from app.services.account_pool import (
    iter_pool_clients,
    bump_cooldown,
    mark_flood,
    mark_limit,
)
from app.services.membership_db import (
    init as memb_init,
    upsert_membership,
    get_membership,
    any_final_for_channel,
    url_get,
    url_put,
)
from app.services.link_queue import (
    init as lq_init,
    enqueue as lq_enqueue,
    fetch_due as lq_fetch_due,
    mark_processing as lq_mark_processing,
    mark_done as lq_mark_done,
    mark_failed as lq_mark_failed,
)

log = logging.getLogger("plugin.batch_links")

# --- гнучкі паузи між URL-ами (окремо для public/invite) ---
LINK_DELAY_PUBLIC_MIN = float(os.getenv("LINK_DELAY_PUBLIC_MIN", "2"))
LINK_DELAY_PUBLIC_MAX = float(os.getenv("LINK_DELAY_PUBLIC_MAX", "4"))
LINK_DELAY_INVITE_MIN = float(os.getenv("LINK_DELAY_INVITE_MIN", "6"))
LINK_DELAY_INVITE_MAX = float(os.getenv("LINK_DELAY_INVITE_MAX", "10"))

def _clamp_pair(lo: float, hi: float) -> tuple[float, float]:
    lo = max(lo, 0.0)
    if hi < lo: hi = lo
    return lo, hi

LINK_DELAY_PUBLIC_MIN, LINK_DELAY_PUBLIC_MAX = _clamp_pair(LINK_DELAY_PUBLIC_MIN, LINK_DELAY_PUBLIC_MAX)
LINK_DELAY_INVITE_MIN, LINK_DELAY_INVITE_MAX = _clamp_pair(LINK_DELAY_INVITE_MIN, LINK_DELAY_INVITE_MAX)

DB_PATH = os.getenv("DB_PATH", "post_watchdog.sqlite3")

# --- state ---
_MONITOR_ENABLED: bool = False
_MONITOR_CHAT_ID: Optional[int] = None
_CONTROL_PEER_ID: Optional[int] = None


async def _throttle_between_links(kind: Optional[str], url: str = ""):
    """
    kind: 'invite' | 'public' | None
    Якщо kind невідомий, визначаємо по url ("/+" | "joinchat" => invite).
    """
    is_inv = (kind == "invite") or ("/+" in (url or "")) or ("joinchat" in (url or ""))
    if is_inv:
        lo, hi = LINK_DELAY_INVITE_MIN, LINK_DELAY_INVITE_MAX
        label = "invite"
    else:
        lo, hi = LINK_DELAY_PUBLIC_MIN, LINK_DELAY_PUBLIC_MAX
        label = "public"

    delay = random.uniform(lo, hi)
    log.debug("throttle(%s): sleep %.2fs", label, delay)
    await asyncio.sleep(delay)


def _display_name(slot) -> str:
    try:
        client = getattr(slot, "client", slot)
        sess = getattr(getattr(client, "session", None), "filename", None)
        if sess:
            return str(sess)
    except Exception:
        pass
    for attr in ("name", "label", "session_name"):
        if hasattr(slot, attr):
            try:
                v = getattr(slot, attr)
                if v:
                    return str(v)
            except Exception:
                pass
    return "slot"


async def process_links(message, text: str):
    links = extract_links(text)
    if not links:
        await message.reply("❌ Посилань не знайдено")
        return

    results: List[str] = []
    used = set()

    # використовуємо перший вільний клієнт для probe channel_id
    probe_client = None
    slots_probe = list(iter_pool_clients())
    if slots_probe:
        probe_client = getattr(slots_probe[0], "client", slots_probe[0])

    log.info("batch start: raw=%d uniq=%d", len(links), len(set(links)))

    for idx, url in enumerate(links, start=1):
        if url in used:
            results.append(f"{idx}. {url} — 🔁 дублікат")
            await _throttle_between_links(None, url)
            continue
        used.add(url)

        # 0) спробуємо визначити channel_id без вступу
        channel_id = None
        if probe_client is not None:
            try:
                cid, _, _, _ = await probe_channel_id(probe_client, url)
                channel_id = cid
            except Exception:
                channel_id = None

        # 0.1) якщо channel_id відомий — перевіряємо глобальний кеш по каналу
        if channel_id is not None:
            final = any_final_for_channel(channel_id)
            if final:
                log.debug("skip by channel cache: url=%s cid=%s status=%s", url, channel_id, final)
                results.append(f"{idx}. {url} — ☑️ кеш({final})")
                await _throttle_between_links(None, url)
                continue
        else:
            # 0.2) channel_id невідомий → дивимось URL-кеш (для інвайтів до першого join)
            ust = url_get(url)
            if ust in ("joined","already","requested","invalid","private"):
                log.debug("skip by url cache: url=%s status=%s", url, ust)
                results.append(f"{idx}. {url} — ☑️ кеш({ust})")
                await _throttle_between_links(None, url)
                continue

        # 1) беремо актуальні слоти кожного разу
        slots = list(iter_pool_clients())
        if not slots:
            # кладемо поточний і решту, які ще не пройшли, у чергу — нічого не губимо
            rest = [url] + [u for u in links[idx:] if u not in used]
            added = lq_enqueue(rest, batch_id="batch:"+str(message.id), origin_chat=message.chat_id, origin_msg=message.id)
            results.append(f"{idx}. {url} — 💤 немає вільних акаунтів; поставив у чергу {added} URL")
            break

        line = None
        last_kind = None

        for slot in slots:
            client = getattr(slot, "client", slot)
            who = _display_name(slot)

            # 1.1) пер-акаунтний кеш: якщо акаунт мав фінальний статус у каналі — пропускаємо його
            if channel_id is not None:
                acc_status = get_membership(who, channel_id)
                if acc_status in ("joined","already","requested","invalid","private","blocked","too_many"):
                    continue

            # 1.2) реальна спроба
            status, title, kind, cid_after, _ = await ensure_join(client, url)
            last_kind = kind
            cid_eff = channel_id or cid_after

            # 1.3) запис у БД для цього акаунта (фінальні стани)
            if cid_eff is not None and status in ("joined","already","requested","invalid","private","blocked","too_many"):
                upsert_membership(who, cid_eff, status)

            # 1.4) якщо channel_id так і не з’явився, але статус фінальний — кеш по URL
            if cid_eff is None and status in ("joined","already","requested","invalid","private"):
                url_put(url, status)

            # 1.5) рендер/керування пулом
            if status == "already":
                line = f"{idx}. {url} — ↪️ вже підписаний [{who}]"
                break

            elif status == "joined":
                line = f"{idx}. {url} — ✅ підписано [{who}]"
                jitter = int(random.uniform(8, 12)) if kind == "invite" else int(random.uniform(3, 5))
                bump_cooldown(client, jitter)
                break

            elif status == "requested":
                line = f"{idx}. {url} — 📨 заявка на вступ відправлена [{who}]"
                bump_cooldown(client, int(random.uniform(6, 8)))
                break

            elif status == "invalid":
                line = f"{idx}. {url} — ❌ невалідне посилання [{who}]"
                break

            elif status == "private":
                line = f"{idx}. {url} — 🔒 приватний/неприєднуваний [{who}]"
                break

            elif status == "blocked":
                line = f"{idx}. {url} — 🚫 обмеження для цього акаунта [{who}]"
                # інші акаунти можуть спробувати
                continue

            elif status == "too_many":
                line = f"{idx}. {url} — ⚠️ ліміт каналів на акаунті [{who}]"
                try:
                    mark_limit(slot, days=2)
                except Exception:
                    pass
                # інші акаунти можуть спробувати
                continue

            elif isinstance(status, str) and status.startswith("flood_wait"):
                try:
                    sec = int(str(status).split("_")[-1])
                except Exception:
                    sec = 60
                line = f"{idx}. {url} — ⏳ FLOOD_WAIT {sec}s [{who}]"
                try:
                    mark_flood(client, int(sec))
                except Exception:
                    pass
                # продовжуємо іншими слотами
                continue

            else:
                line = f"{idx}. {url} — ⚠️ {status} [{who}]"
                # не фінальне — спробуємо іншим слотом
                continue

        if not line:
            line = f"{idx}. {url} — ⚠️ pending"

        results.append(line)
        await _throttle_between_links(last_kind, url)

    text_out = "\n".join(results)
    text_out += f"\n\nУнікальних: {len(used)} / {len(links)}"
    await message.reply(text_out)
    log.info("batch done: total=%d uniq=%d", len(links), len(set(links)))


async def _run_link_queue_worker(client):
    """
    Воркер: тягне Pending URL з БД і обробляє їх по одному, коли слоти готові.
    """
    log.info("link_queue worker started")
    while True:
        try:
            # якщо немає готових слотів — почекаємо
            slots_now = list(iter_pool_clients())
            if not slots_now:
                await asyncio.sleep(5)
                continue

            items = lq_fetch_due(limit=10)
            if not items:
                await asyncio.sleep(3)
                continue

            for item_id, url, tries, origin_chat, origin_msg in items:
                lq_mark_processing(item_id)

                # кеші
                probe_client = getattr(slots_now[0], "client", slots_now[0])
                channel_id = None
                try:
                    cid, _, _, _ = await probe_channel_id(probe_client, url)
                    channel_id = cid
                except Exception:
                    channel_id = None

                if channel_id is not None:
                    final = any_final_for_channel(channel_id)
                    if final:
                        lq_mark_done(item_id)
                        continue
                else:
                    ust = url_get(url)
                    if ust in ("joined","already","requested","invalid","private"):
                        lq_mark_done(item_id)
                        continue

                # вибір слота
                slots_now = list(iter_pool_clients())
                if not slots_now:
                    lq_mark_failed(item_id, "no_slots", backoff_sec=15, max_retries=20)
                    continue

                processed = False
                last_kind = None

                for slot in slots_now:
                    cli = getattr(slot, "client", slot)
                    who = _display_name(slot)

                    if channel_id is not None:
                        acc_status = get_membership(who, channel_id)
                        if acc_status in ("joined","already","requested","invalid","private","blocked","too_many"):
                            continue

                    status, title, kind, cid_after, _ = await ensure_join(cli, url)
                    last_kind = kind
                    cid_eff = channel_id or cid_after

                    if cid_eff is not None and status in ("joined","already","requested","invalid","private","blocked","too_many"):
                        upsert_membership(who, cid_eff, status)

                    if cid_eff is None and status in ("joined","already","requested","invalid","private"):
                        url_put(url, status)

                    if status in ("already","joined","requested","invalid","private"):
                        lq_mark_done(item_id)
                        processed = True
                        await _throttle_between_links(last_kind, url)
                        break

                    elif status == "blocked":
                        continue

                    elif status == "too_many":
                        try:
                            mark_limit(slot, days=2)
                        except Exception:
                            pass
                        continue

                    elif isinstance(status, str) and status.startswith("flood_wait"):
                        try:
                            sec = int(str(status).split("_")[-1])
                        except Exception:
                            sec = 60
                        try:
                            mark_flood(cli, int(sec))
                        except Exception:
                            pass
                        continue

                    else:
                        lq_mark_failed(item_id, f"temp:{status}", backoff_sec=20, max_retries=20)
                        processed = True
                        break

                if not processed:
                    lq_mark_failed(item_id, "no_slot_processed", backoff_sec=30, max_retries=20)

        except Exception as e:
            log.exception("link_queue worker loop error: %s", e)
            await asyncio.sleep(5)


def setup(client, control_peer=None, monitor_buffer=None, **kwargs):
    global _CONTROL_PEER_ID
    _CONTROL_PEER_ID = control_peer

    memb_init(DB_PATH)
    lq_init(DB_PATH)

    log.info("batch_links: setup(control_peer=%s, monitor_buffer=%s)", control_peer, monitor_buffer)

    @client.on(events.NewMessage(pattern=r'^/monitor_links_on$'))
    async def _on(evt):
        if _CONTROL_PEER_ID is not None and evt.chat_id != _CONTROL_PEER_ID:
            return
        global _MONITOR_ENABLED, _MONITOR_CHAT_ID
        _MONITOR_ENABLED = True
        _MONITOR_CHAT_ID = evt.chat_id
        await evt.reply("🟢 Режим додавання лінків увімкнено. Надішли список t.me-посилань одним повідомленням.")

    @client.on(events.NewMessage(pattern=r'^/monitor_links_off$'))
    async def _off(evt):
        if _CONTROL_PEER_ID is not None and evt.chat_id != _CONTROL_PEER_ID:
            return
        global _MONITOR_ENABLED, _MONITOR_CHAT_ID
        _MONITOR_ENABLED = False
        _MONITOR_CHAT_ID = None
        await evt.reply("🔴 Режим додавання лінків вимкнено.")

    @client.on(events.NewMessage(pattern=r'^/monitor_links_status$'))
    async def _status(evt):
        if _CONTROL_PEER_ID is not None and evt.chat_id != _CONTROL_PEER_ID:
            return
        await evt.reply(f"ℹ️ monitor_links: {'ON' if _MONITOR_ENABLED else 'OFF'}; chat={_MONITOR_CHAT_ID}")

    @client.on(events.NewMessage())
    async def _msg(evt):
        if _CONTROL_PEER_ID is not None and evt.chat_id != _CONTROL_PEER_ID:
            return
        if not _MONITOR_ENABLED:
            return
        if _MONITOR_CHAT_ID is not None and evt.chat_id != _MONITOR_CHAT_ID:
            return

        text = evt.raw_text or ""
        if re.search(r"https?://t\.me/", text) or re.search(r"(?:^|\\s)@\\w+", text):
            try:
                await process_links(evt.message, text)
            except Exception as e:
                log.exception("batch_links error: %s", e)
                await evt.reply(f"⚠️ Помилка обробки: {e}")

    # --- запускаємо воркер черги ---
    try:
        client.loop.create_task(_run_link_queue_worker(client))
    except Exception:
        asyncio.create_task(_run_link_queue_worker(client))

    log.info("batch_links plugin loaded")